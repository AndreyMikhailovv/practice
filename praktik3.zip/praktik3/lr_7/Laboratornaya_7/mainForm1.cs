﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;


namespace Laboratornaya_7
{
    public partial class mainForm1 : Form
    {
        private string filename = "../../Results.xml";

        public mainForm1()
        {
            InitializeComponent();
        }

        private void LoadXml()
        {
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filename);

            XmlElement xmlRoot = xmlDoc.DocumentElement;

            foreach (XmlNode xmlNode in xmlRoot)
            {
                string id = "";
                string name = "";
                string score = "";
                string time = "";

                if (xmlNode.Attributes.Count > 0)
                {                   
                    XmlNode attr = xmlNode.Attributes.GetNamedItem("id");
                    if (attr != null) 
                                      
                        id = attr.Value;
                }
               
                foreach (XmlNode childNode in xmlNode.ChildNodes)
                {                  
                    if (childNode.Name == "name")
                    {                       
                        name = childNode.InnerText.ToString();
                    }
                    
                    if (childNode.Name == "score")
                    {                      
                        score = childNode.InnerText.ToString();
                    }

                    if (childNode.Name == "time")
                    {
                        time = childNode.InnerText.ToString();
                    }


                }
                
                addPlayerToList(id, name, score, time);
            }
        }

        private void addPlayerToList(string id, string name, string score, string time)
        {
            ListViewItem lvi = new ListViewItem(id);
            lvi.SubItems.Add(name);
            lvi.SubItems.Add(score);
            lvi.SubItems.Add(time);
            listOfPlayers.Items.Add(lvi);
        }

        private void mainForm1_Load(object sender, EventArgs e)
        {
            LoadXml();
        }

        private void addToXml()
        {
            XmlDocument xmlDoc = new XmlDocument(); 
            xmlDoc.Load(filename); 
            XmlElement xmlRoot = xmlDoc.DocumentElement; 

            XmlElement playerElem = xmlDoc.CreateElement("player");
            XmlAttribute idAttr = xmlDoc.CreateAttribute("id");
            
            XmlElement nameElem = xmlDoc.CreateElement("name");
            XmlElement scoreElem = xmlDoc.CreateElement("score");
            XmlElement timeElem = xmlDoc.CreateElement("time");


            XmlText idText = xmlDoc.CreateTextNode((xmlRoot.ChildNodes.Count + 1).ToString());
            XmlText nameText = xmlDoc.CreateTextNode(txtName.Text);
            XmlText scoreText = xmlDoc.CreateTextNode(txtScore.Text);
            XmlText timeText = xmlDoc.CreateTextNode(txtTime.Text);

            idAttr.AppendChild(idText);
            nameElem.AppendChild(nameText);
            scoreElem.AppendChild(scoreText);
            timeElem.AppendChild(timeText);

            playerElem.Attributes.Append(idAttr);
            playerElem.AppendChild(nameElem);
            playerElem.AppendChild(scoreElem);
            playerElem.AppendChild(timeElem);

            xmlRoot.AppendChild(playerElem);
           
            xmlDoc.Save(filename);
           
            string id = (xmlRoot.ChildNodes.Count + 1).ToString();
            string name = txtName.Text;
            string score = txtScore.Text;
            string time = txtTime.Text;
            addPlayerToList(id, name, score, time);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            addToXml();
            txtName.Clear();
            txtScore.Clear();
            txtTime.Clear();
        }
    }
}
