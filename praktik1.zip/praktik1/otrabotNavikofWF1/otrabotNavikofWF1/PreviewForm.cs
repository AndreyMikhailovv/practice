﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otrabotNavikofWF1
{
    public partial class PreviewForm : Form
    {
        public PreviewForm(string name, string surname, string section, string filename)
        {
            InitializeComponent();
            labelName.Text = name.ToUpper();
            labelSecName.Text = surname.ToUpper();
            labelSection.Text = section.ToUpper();
            pictureBox1.Load(filename);
            correctDataDisplay();
        }

        private void printBut_Click(object sender, EventArgs e)
        {
            CaptureScreen();
            printDocument1.Print();
        }

        private void correctDataDisplay()
        {
            if (labelName.Text.Length > 16) labelName.Font = new Font("Arial Narrow", 8);
            if (labelSecName.Text.Length > 16) labelSecName.Font = new Font("Arial Narrow", 8);
        }

        private Bitmap memoryImage;
        private void CaptureScreen()
        {
            Graphics myGraphics = this.CreateGraphics();
            Size s = this.ClientSize;
            memoryImage = new Bitmap(s.Width, s.Height, myGraphics);
            Graphics memoryGraphics = Graphics.FromImage(memoryImage);
            memoryGraphics.CopyFromScreen(this.Location.X, this.Location.Y, 0, 0, s);
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(memoryImage, 0, 0);
        }
    }
}
