﻿namespace otrabotNavikofWF1
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxSecName = new System.Windows.Forms.TextBox();
            this.comboBoxSection = new System.Windows.Forms.ComboBox();
            this.pictureBoxPhoto = new System.Windows.Forms.PictureBox();
            this.overviewBut = new System.Windows.Forms.Button();
            this.exitBut = new System.Windows.Forms.Button();
            this.printBut = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(59, 55);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(209, 26);
            this.textBoxName.TabIndex = 0;
            this.toolTip1.SetToolTip(this.textBoxName, "Поле ввода имени");
            this.textBoxName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxName_KeyPress);
            // 
            // textBoxSecName
            // 
            this.textBoxSecName.Location = new System.Drawing.Point(59, 145);
            this.textBoxSecName.Name = "textBoxSecName";
            this.textBoxSecName.Size = new System.Drawing.Size(209, 26);
            this.textBoxSecName.TabIndex = 1;
            this.toolTip1.SetToolTip(this.textBoxSecName, "Поле вода фамилии");
            this.textBoxSecName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxName_KeyPress);
            // 
            // comboBoxSection
            // 
            this.comboBoxSection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSection.FormattingEnabled = true;
            this.comboBoxSection.Items.AddRange(new object[] {
            "Искусственный интеллект",
            "Компьютерная графика",
            "Разработка игр"});
            this.comboBoxSection.Location = new System.Drawing.Point(59, 235);
            this.comboBoxSection.Name = "comboBoxSection";
            this.comboBoxSection.Size = new System.Drawing.Size(209, 28);
            this.comboBoxSection.Sorted = true;
            this.comboBoxSection.TabIndex = 2;
            this.toolTip1.SetToolTip(this.comboBoxSection, "Выбор секции");
            // 
            // pictureBoxPhoto
            // 
            this.pictureBoxPhoto.BackColor = System.Drawing.Color.SlateBlue;
            this.pictureBoxPhoto.Location = new System.Drawing.Point(349, 55);
            this.pictureBoxPhoto.Name = "pictureBoxPhoto";
            this.pictureBoxPhoto.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPhoto.TabIndex = 3;
            this.pictureBoxPhoto.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBoxPhoto, "В этом окне показывается выбранное фото");
            // 
            // overviewBut
            // 
            this.overviewBut.BackColor = System.Drawing.Color.DimGray;
            this.overviewBut.Location = new System.Drawing.Point(399, 235);
            this.overviewBut.Name = "overviewBut";
            this.overviewBut.Size = new System.Drawing.Size(100, 28);
            this.overviewBut.TabIndex = 4;
            this.overviewBut.Text = "Обзор...";
            this.toolTip2.SetToolTip(this.overviewBut, "При нажатии на данную кнопку, вы сможете выбрать нужное изображение на вашем комп" +
        "ьютере");
            this.overviewBut.UseVisualStyleBackColor = false;
            this.overviewBut.Click += new System.EventHandler(this.overviewBut_Click);
            // 
            // exitBut
            // 
            this.exitBut.BackColor = System.Drawing.Color.PaleVioletRed;
            this.exitBut.Location = new System.Drawing.Point(125, 300);
            this.exitBut.Name = "exitBut";
            this.exitBut.Size = new System.Drawing.Size(150, 35);
            this.exitBut.TabIndex = 5;
            this.exitBut.Text = "Выйти";
            this.toolTip1.SetToolTip(this.exitBut, "При нажатии на кнопку осуществляется выход из приложения");
            this.exitBut.UseVisualStyleBackColor = false;
            this.exitBut.Click += new System.EventHandler(this.exitBut_Click);
            // 
            // printBut
            // 
            this.printBut.BackColor = System.Drawing.Color.SlateBlue;
            this.printBut.Location = new System.Drawing.Point(312, 300);
            this.printBut.Name = "printBut";
            this.printBut.Size = new System.Drawing.Size(150, 35);
            this.printBut.TabIndex = 6;
            this.printBut.Text = "Распечатать бейдж";
            this.toolTip1.SetToolTip(this.printBut, "Открыть окно предварительного просмотра перед печатью");
            this.printBut.UseVisualStyleBackColor = false;
            this.printBut.Click += new System.EventHandler(this.printBut_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 20);
            this.label1.TabIndex = 7;
            this.label1.Text = "Имя";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 122);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 20);
            this.label2.TabIndex = 8;
            this.label2.Text = "Фамилия";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 20);
            this.label3.TabIndex = 9;
            this.label3.Text = "Секция";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(345, 32);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 20);
            this.label4.TabIndex = 10;
            this.label4.Text = "Фото";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|*.BMP;*.JPG;*.GIF| All files (*.*)|*.*";
            // 
            // toolTip2
            // 
            this.toolTip2.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.toolTip2.ToolTipTitle = "Кнопка ОБЗОР";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.printBut);
            this.Controls.Add(this.exitBut);
            this.Controls.Add(this.overviewBut);
            this.Controls.Add(this.pictureBoxPhoto);
            this.Controls.Add(this.comboBoxSection);
            this.Controls.Add(this.textBoxSecName);
            this.Controls.Add(this.textBoxName);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ввод информации";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPhoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxSecName;
        private System.Windows.Forms.ComboBox comboBoxSection;
        private System.Windows.Forms.PictureBox pictureBoxPhoto;
        private System.Windows.Forms.Button overviewBut;
        private System.Windows.Forms.Button exitBut;
        private System.Windows.Forms.Button printBut;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

